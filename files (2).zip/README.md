# Reactor Data Monitoring & Viscosity Prediction System

**Author:** James Daramola  
**Department:** Electrical and Computer Engineering  
**Date:** May 2026

---

## Overview

A fully automated Big Data pipeline that monitors a chemical reactor and predicts viscosity 10 minutes ahead using Apache Spark, AWS S3, and Random Forest machine learning. The operator drops a folder of CSV files and within 6 minutes, predictions appear on a live web dashboard — fully automatically.

---

## Key Results

| Metric | Value |
|--------|-------|
| R² (Accuracy) | 0.9978 |
| RMSE | 23.02 cP |
| Mean Absolute Error | 0.76 cP |
| Total Predictions | 360,847 |
| Pipeline Speed | ~60 seconds (EC2) |
| End-to-End | ~6 minutes |
| Training Rows | 1,264,251 |
| Test Rows | 315,745 |
| Batches | 75 real production batches |

---

## Repository Structure

```
reactor-viscosity-prediction/
├── README.md
├── requirements.txt
├── ec2_scripts/
│   ├── pipeline.py          # Master pipeline — 4 stages
│   ├── dashboard.py         # Plotly Dash web dashboard
│   ├── run_pipeline.sh      # Environment loader for SSH
│   └── start_hadoop.sh      # Hadoop auto-start on boot
├── scripts/
│   ├── watch_and_upload.ps1 # Windows folder watcher
│   └── start_reactor.ps1    # Morning auto-startup
├── utils/
│   ├── view_silver.py       # Inspect cleaned Silver data
│   ├── view_gold.py         # Inspect ML-ready Gold data
│   └── view_predictions.py  # Inspect prediction results
└── docs/
    └── architecture.md      # System architecture notes
```

---

## System Architecture

```
Plant Historian → Windows PC → AWS S3 Bronze → AWS EC2 → Dashboard
                  (watcher)    (raw archive)   (Spark)    (:8050)
```

### Data Lake Layers

| Layer | Contents | Format |
|-------|----------|--------|
| Bronze | Raw CSV — never modified | CSV |
| Silver | Cleaned data | Parquet |
| Gold | ML features + predictions | Parquet |

---

## Quick Start

### Prerequisites

- AWS account with EC2 and S3 access
- Windows PC with PowerShell and AWS CLI
- EC2 instance: Ubuntu 22.04, m7i-flex.large
- Software: Java 11, Hadoop 3.3.6, Spark 3.5.1, Hive 3.1.3

### Every Morning

```powershell
# Start EC2
aws ec2 start-instances --instance-ids i-084fd00b0356d1b12

# Get new IP
aws ec2 describe-instances --query "Reservations[*].Instances[*].[InstanceId,State.Name,PublicIpAddress]" --output table

# Update watcher IP
(Get-Content "scripts\watch_and_upload.ps1") -replace 'OLD-IP', 'NEW-IP' | Set-Content "scripts\watch_and_upload.ps1"

# Start watcher
powershell -ExecutionPolicy Bypass -File "scripts\watch_and_upload.ps1"
```

### On EC2

```bash
start-dfs.sh && start-yarn.sh
nohup python3 ~/dashboard.py > ~/dashboard.log 2>&1 &
```

### Process New Data

Drop CSV folder into `incoming_csv\` — everything else is automatic.

### Every Evening

```powershell
aws ec2 stop-instances --instance-ids i-084fd00b0356d1b12
```

---

## Feature Engineering

| Feature | Type | Purpose |
|---------|------|---------|
| temp_rolling_avg_5 | Noise filter | Remove ±2°C sensor noise |
| ph_rolling_avg_5 | Noise filter | Remove pH sensor noise |
| visc_rolling_avg_5 | Noise filter | Smooth viscosity readings |
| viscosity_lag_1 | Memory | Viscosity 1 step ago |
| viscosity_lag_5 | Memory | Viscosity 5 steps ago |
| viscosity_lag_10 | Memory | Viscosity 10 steps ago |
| temp_lag_1 | Memory | Temperature 1 step ago |
| temp_rate_change | Momentum | How fast temperature is changing |
| ph_rate_change | Momentum | How fast pH is changing |
| visc_rate_change | Momentum | How fast viscosity is changing |
| batch_progress_pct | Context | What % of batch is complete |
| batch_time_mins | Context | Elapsed batch time |
| viscosity_target_10min | Label | Actual viscosity 10 steps ahead |

**Critical:** All features use `Window.partitionBy('batch_id')` to prevent cross-batch contamination. Without this R²=0.41. With it R²=0.9978.

---

## Infrastructure

| Component | Value |
|-----------|-------|
| S3 Bucket | reactor-project-emperor1 |
| EC2 Instance | i-084fd00b0356d1b12 |
| EC2 Type | m7i-flex.large |
| OS | Ubuntu 22.04 |
| Java | OpenJDK 11 |
| Hadoop | 3.3.6 |
| Spark | 3.5.1 |
| Hive | 3.1.3 |
| AWS Cost | ~$0.05/hour |

---

## License

MIT License — see LICENSE file for details.
